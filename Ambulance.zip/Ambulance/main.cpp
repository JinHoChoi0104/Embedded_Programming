#include "mainwindow.h"

#include <QApplication>

//void Set_Position();



